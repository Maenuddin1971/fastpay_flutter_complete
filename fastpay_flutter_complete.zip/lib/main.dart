
// Simplified content for main.dart
void main() {
  print("Fastpay App Started");
}
